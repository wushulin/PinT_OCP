clear; 
clc;
clf;
close all;
ALP_flag=1; % if you do not run ALP, just the standard Nesterov, set ALP_flag to 0
mainDir = fileparts(mfilename('fullpath'));
commonDir = fullfile(mainDir, 'Common Data and Functions');
addpath(genpath(commonDir));
Common_Data;
global Standard_GD_flag NAG_flag
global  CGC_flag mu
Standard_GD_flag=1;
NAG_flag=0; 
CGC_flag=0;
%plot_flag=3; %plot_flag=1: Gradient_norm; plot_flag=2: error_u; plot_flag=3: error_y

NAG_se=NAG_s;
NAG_Kmax=2500;
mu=1;
%mu=3.5;kk=[10,80,300];
%--------- Compute yd and yT---------
yd0=transpose(yhat2dmh(msh.p(:, 1)', msh.p(:, 2)', t_f', kap, b, T)); % global target with boundary nodes
yd=yd0(msh.in,:);
yT=yd(:,end);
y_ini=yd(:,1);
y0=y_ini;
if Standard_GD_flag==1
    %---------- Nesterov in fine time grid-----------
    GD_yk_f=yd;
    GD_yk_f(:,1)=y_ini;
    GD_pk_f=zeros(Nx,Nt_f+1);
    GD_uk_f=zeros(Nx,Nt_f+1);
    GD_vk_f=GD_uk_f;
    Gradient_norm=zeros(1,NAG_Kmax);
    Error_y=zeros(1,NAG_Kmax);
    Error_u=zeros(1,NAG_Kmax);
    a0=1;
    for k=1:NAG_Kmax
        for n=1:Nt_f 
           bn=(1-theta)*GD_uk_f(:,n)+theta*GD_uk_f(:,n+1); 
           GD_yk_f(:,n+1)= invAf*((Ix-dt_f*(1-theta)*A)*GD_yk_f(:,n)+dt_f*bn);
        end

        GD_pk_f(:,end)=beta*(yT-GD_yk_f(:,end));
        for n=Nt_f:-1:1
            bn=(1-theta)*alpha*(yd(:,n)-GD_yk_f(:,n))+theta*alpha*(yd(:,n+1)-GD_yk_f(:,n+1));
            GD_pk_f(:,n)=TI_p(invAfp,Ap,GD_pk_f(:,n+1),dt_f,bn);
        end 

        if NAG_flag==1
            v_new=GD_uk_f-NAG_s*dJ(GD_uk_f,GD_pk_f);
            a1=(1+sqrt(1+4*a0^2))/2;
            u_new=v_new+(a0-1)*(v_new-GD_vk_f)/a1;
            a0=a1;
            GD_uk_f=u_new;
            GD_vk_f=v_new; 
        else
            GD_uk_f=GD_uk_f-NAG_s*dJ(GD_uk_f,GD_pk_f); 
        end

        Gradient_norm(k)=norm(dJ(GD_uk_f,GD_pk_f),inf); 
        Error_u(k)=norm(GD_uk_f-u_ref,'fro')/norm(u_ref,'fro');
        Error_y(k)=norm(GD_yk_f-y_ref,'fro')/norm(y_ref,'fro');
        if mod(k,20)==0
            figure(1);
            semilogy(1:k,Error_y(1:k),'k-','LineWidth',2);
            set(gca,'fontsize',18);
            ylabel('$\|\mathbf{y}_{\rm ref}-\mathbf{y}^l\|_\infty$','interpreter','latex','fontsize',21);
            ylim([0,0.05+1.15*max(Error_y)]);
            xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
            xlim([1,k+1]);
            fprintf('Error for (u, y) after %d-Nesterov iters is: (%2.6f, %2.6f)\n',k,Error_u(k),Error_y(k));  
            figure(2);
            semilogy(1:k,Error_u(1:k),'k-','LineWidth',2);
            set(gca,'fontsize',18);
            ylabel('$\|\mathbf{u}_{\rm ref}-\mathbf{u}^l\|_\infty$','interpreter','latex','fontsize',21);
            xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
            ylim([0,0.05+1.15*max(Error_u)]);
            xlim([1,k+1]);
            figure(3);
            semilogy(1:k,Gradient_norm(1:k),'k-','LineWidth',2);
            set(gca,'fontsize',18);
            ylabel('$\|\nabla \mathcal{J}(\mathbf{u}^l)\|_\infty$','interpreter','latex','fontsize',21);
            xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
            xlim([1,k+1]);
        end
    end
end

Error_y_GD=Error_y;
Error_u_GD=Error_u;
Gradient_norm_GD=Gradient_norm;

if ALP_flag==1 
    %---------- Nesterov with ALP-----------
    GD_yk_f=zeros(Nx,Jf+1,Nt);
    for n=1:Nt
        GD_yk_f(:,:,n)=yd(:,(n-1)*Jf+1:n*Jf+1);
    end
    GD_yk_f(:,1,1)=y0;  

    GD_pk_f=zeros(Nx,Jf+1,Nt);
    GD_pk_f(:,Jf+1,Nt)=beta*(yT-GD_yk_f(:,Jf+1,Nt));
    GD_uk_f=zeros(Nx,Jf+1,Nt);
    GD_vk_f=GD_uk_f; 
    GD_etak_c=zeros(Nx,Nt+1);
    GD_etak_c(:,1)=y0;GD_etak_c(:,end)=yT; % GD_etak_c(:,n) for n=1 and n=Nt+1 are NOT updated
    GD_tetak_c=GD_etak_c;

    Gradient_norm=zeros(NAG_Kmax,1); 
    Error_y=zeros(1,NAG_Kmax);
    Error_u=zeros(1,NAG_Kmax);
    a0=1;
    b0=1;
    for k=1:NAG_Kmax
         for n=1:Nt
                Fine_y_n=zeros(Nx,Jf+1);
                Fine_y_n(:,1)=GD_etak_c(:,n);
                for j=1:Jf
                    bn=(1-theta)*GD_uk_f(:,j,n)+theta*GD_uk_f(:,j+1,n);
                    Fine_y_n(:,j+1)=TI_y(invAf,A,Fine_y_n(:,j),dt_f,bn);
                end
                GD_yk_f(:,:,n)=Fine_y_n;    
                Fine_p_n=zeros(Nx,Jf+1); 
                if n==Nt
                    Fine_p_n(:,end)=beta*(yT-GD_yk_f(:,Jf+1,n));
                else
                    Fine_p_n(:,end)=mu*(GD_etak_c(:,n+1)-GD_yk_f(:,Jf+1,n)); % add the penalty Lagrange here
                end
                for j=Jf:-1:1
                    bn=alpha*((1-theta)*(yd(:,(n-1)*Jf+j)-GD_yk_f(:,j,n))+theta*(yd(:,(n-1)*Jf+j+1)-GD_yk_f(:,j+1,n)));
                    Fine_p_n(:,j)=TI_p(invAfp,Ap,Fine_p_n(:,j+1),dt_f,bn);
                end
                GD_pk_f(:,:,n)=Fine_p_n; 
                % update the control 
                if NAG_flag==1
                    v_new=GD_uk_f(:,:,n)-NAG_s*dJ(GD_uk_f(:,:,n),Fine_p_n);
                    a1=(1+sqrt(1+4*a0^2))/2;
                    u_new=v_new+(a0-1)*(v_new-GD_vk_f(:,:,n))/a1;
                    a0=a1;
                    GD_uk_f(:,:,n)=u_new;
                    GD_vk_f(:,:,n)=v_new;
                else
                    GD_uk_f(:,:,n)=GD_uk_f(:,:,n)-NAG_s*dJ(GD_uk_f(:,:,n),Fine_p_n);
                end
         end
          
          Res=zeros(Nx,Nt-1);
          for n=2:Nt
              Res(:,n-1)=GD_pk_f(:,Jf+1,n-1)-GD_pk_f(:,1,n);
          end
          if CGC_flag==1
               teta_c1=zeros(Nx,Nt);
               for n=Nt-1:-1:1
                   teta_c1(:,n)=TI_p(invAcp,Ap,teta_c1(:,n+1),dt_c,Res(:,n));
               end
               teta_c2=zeros(Nx,Nt);
               for n=1:Nt-1
                   teta_c2(:,n+1)=TI_y(invAc,A,teta_c2(:,n),dt_c,teta_c1(:,n));
               end
               Res=teta_c2(:,2:Nt);
          end 
          for n=2:Nt               
            if NAG_flag==1
                teta_new=GD_etak_c(:,n)-NAG_se*Res(:,n-1);  
                b1=(1+sqrt(1+4*b0^2))/2;
                eta_new=teta_new+(b0-1)*(teta_new-GD_tetak_c(:,n))/b1;
                b0=b1;
                GD_etak_c(:,n)=eta_new;
                GD_tetak_c(:,n)=teta_new;
            else
                GD_etak_c(:,n)=GD_etak_c(:,n)-NAG_se*Res(:,n-1);  
            end
        end
         
          % glue the internal interface value at T2, T3, .., T_Nt
         pk=zeros(Nx,Nt_f+1); 
         pk(:,1)=GD_pk_f(:,1,1); 
         pk(:,end)=GD_pk_f(:,Jf+1,end); 


         yk=zeros(Nx,Nt_f+1);
         yk(:,1)=GD_yk_f(:,1,1);
         yk(:,end)=GD_yk_f(:,Jf+1,end);


         uk=zeros(Nx,Nt_f+1);        
         uk(:,1)=GD_uk_f(:,1,1);         
         uk(:,end)=GD_uk_f(:,Jf+1,end);

        vk=zeros(Nx,Nt_f+1);        
        vk(:,1)=GD_vk_f(:,1,1);         
        vk(:,end)=GD_vk_f(:,Jf+1,end);
        for n=1:Nt
              yk(:,(n-1)*Jf+2:n*Jf)=GD_yk_f(:,2:Jf,n); 
              pk(:,(n-1)*Jf+2:n*Jf)=GD_pk_f(:,2:Jf,n); 
              uk(:,(n-1)*Jf+2:n*Jf)=GD_uk_f(:,2:Jf,n);       
              vk(:,(n-1)*Jf+2:n*Jf)=GD_vk_f(:,2:Jf,n);   
              if n>1
                  yk(:,(n-1)*Jf+1)=0.5*(GD_yk_f(:,Jf+1,n-1)+GD_yk_f(:,1,n));
                  pk(:,(n-1)*Jf+1)=0.5*(GD_pk_f(:,Jf+1,n-1)+GD_pk_f(:,1,n));  
                  uk(:,(n-1)*Jf+1)=0.5*(GD_uk_f(:,Jf+1,n-1)+GD_uk_f(:,1,n));
                  vk(:,(n-1)*Jf+1)=0.5*(GD_vk_f(:,Jf+1,n-1)+GD_vk_f(:,1,n));
              end
        end

        Gradient_norm(k)=norm(dJ(uk,pk),inf); 
        Error_u(k)=norm(uk-u_ref,'fro')/norm(u_ref,'fro');
        Error_y(k)=norm(yk-y_ref,'fro')/norm(y_ref,'fro');
        if mod(k,10)==0
            fprintf('Error for (u, y) after %d-Nesterov iters is: (%2.6f, %2.6f)\n',k,Error_u(k),Error_y(k));  
        end
        if max(max(Error_u(k),Error_y(k)),Gradient_norm(k))>=1e+10
            break;
        end
        % for n=1:Nt
        %     if k==kk(1)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_yk_f(25,:,n),'r-','LineWidth',2);
        %         hold on
        %     elseif k==kk(2)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_yk_f(25,:,n),'b-','LineWidth',2);
        %         hold on
        %     elseif k==kk(3)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_yk_f(25,:,n),'m-','LineWidth',2);
        %         hold on
        %     else
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_yk_f(25,:,n),'-','LineWidth',2);
        %         hold on
        %     end
        % end
        % n=1;
        % plot(t_f(n*Jf+1),GD_yk_f(25,end,n),'ko','LineWidth',2,'MarkerSize',12);
        % for n=2:Nt-1
        %     plot(t_f((n-1)*J+1),GD_yk_f(25,1,n),'ko',t_f(n*Jf+1),GD_yk_f(25,end,n),'ko','LineWidth',2,'MarkerSize',12);
        % end
        % n=Nt;
        % plot(t_f((n-1)*Jf+1),GD_yk_f(25,1,n),'ko','LineWidth',2,'MarkerSize',12);
        % %hold off;
        % 
        % set(gca,'fontsize',16);
        % xlabel('Time: t','FontSize',21,'Interpreter','latex');
        % ylabel('$y(-\frac{1}{2},-\frac{1}{2}, t)$','FontSize',21,'Interpreter','latex');

        % for n=1:Nt
        %     if k==kk(1)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_uk_f(25,:,n),'r-','LineWidth',2);
        %         hold on
        %     elseif k==kk(2)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_uk_f(25,:,n),'b-','LineWidth',2);
        %         hold on
        %     elseif k==kk(3)
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_uk_f(25,:,n),'m-','LineWidth',2);
        %         hold on
        %     else
        %         plot(t_f((n-1)*J+1:n*Jf+1),GD_uk_f(25,:,n),'-','LineWidth',2);
        %         hold on
        %     end
        % end
        % 
        % n=1;
        % plot(t_f(n*Jf+1),GD_uk_f(25,end,n),'ko','LineWidth',2,'MarkerSize',12);
        % for n=2:Nt-1
        %     plot(t_f((n-1)*J+1),GD_uk_f(25,1,n),'ko',t_f(n*Jf+1),GD_uk_f(25,end,n),'ko','LineWidth',2,'MarkerSize',12);
        % end
        % n=Nt;
        % plot(t_f((n-1)*Jf+1),GD_uk_f(25,1,n),'ko','LineWidth',2,'MarkerSize',12);
        %     %hold off;
        % 
        % set(gca,'fontsize',16);
        % xlabel('Time: t','FontSize',21,'Interpreter','latex');
        % ylabel('$u(-\frac{1}{2},-\frac{1}{2}, t)$','FontSize',21,'Interpreter','latex');  
    end
    figure(1);
    ax1 = gca;
    semilogy(1:NAG_Kmax,Error_y_GD(1:NAG_Kmax),'k-',1:k,Error_y(1:k),'--','LineWidth',2);
    set(gca,'fontsize',18);
    ylabel('$\|\mathbf{y}_{\rm ref}-\mathbf{y}^l\|_\infty$','interpreter','latex','fontsize',21);
    ylim([0,0.05+1.15*max(Error_y)]);
    xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
    xlim([1,k+1]);
    
    figure(2);
    ax2 = gca;
    semilogy(1:NAG_Kmax,Error_u_GD(1:NAG_Kmax),'k-',1:k,Error_u(1:k),'--','LineWidth',2);
    set(gca,'fontsize',18);
    ylabel('$\|\mathbf{u}_{\rm ref}-\mathbf{u}^l\|_\infty$','interpreter','latex','fontsize',21);
    xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
    ylim([0,0.05+1.15*max(Error_u)]);
    xlim([1,k+1]);

    figure(3);
    ax3 = gca;
    semilogy(1:NAG_Kmax,Gradient_norm_GD(1:NAG_Kmax),'k-',1:k,Gradient_norm(1:k),'--','LineWidth',2);
    set(gca,'fontsize',18);
    ylabel('$\|\nabla \mathcal{J}(\mathbf{u}^l)\|_\infty$','interpreter','latex','fontsize',21);
    xlabel('Iteration Index $l$','FontSize',21,'Interpreter','latex');
    ylim([0,0.05+1.15*max(Error_u)]);
    xlim([1,k+1]);
end
 
 