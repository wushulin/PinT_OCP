global alpha beta nu  T NAG_s hx  theta J Nx Jf  Nt
theta=1/2;   % time integator parameter theta: {0, 0.5,1}
alpha=1;   % penlty for distribution term
beta=0.00;   % penlty for the terminal term 
nu=1e-6;      % penlty for the control term
 
kap = 2^-1; b = [0 0]; %case I
%kap = 2^-3; b = [1 1]; %case II
NAG_s=1.5;
hx = 2^-3;
T = 2^1;
ht = 0.125*hx;
dt_f=ht;
% J=4;
% J=8;
J=16;
J=32;
Jf=J;
dt_c=J*dt_f;
t_f = 0:dt_f:T;
Nt_f= length(t_f) - 1;
t_c= 0:dt_c:T;
Nt_c= length(t_c) - 1; % time window number
Nt=Nt_c;
%spatial discretization
[Ms, K, C, msh] = SpaceDisLshape(hx, b);
A = Ms\(kap*K + C);
Ap=transpose(A);
Nx = length(msh.in);
Np = size(msh.p, 1);
Ix=speye(Nx);
invAc=Ix/(Ix+dt_c*theta*A);
invAf=Ix/(Ix+dt_f*theta*A);
invAcp=Ix/(Ix+dt_c*theta*Ap);
invAfp=Ix/(Ix+dt_f*theta*Ap);

A0 = kap*K + C;
Nin = length(msh.in); 

%target function
Yhat = yhat2dmh(msh.p(:, 1)', msh.p(:, 2)', t_f', kap, b, T);
%solve entire system
M = BuildThtMatrix2d(Ms, A0, dt_f, Nt_f, nu, alpha, theta, speye(Nin), sparse(Nin, Nin), sparse(Nin, Nin), speye(Nin));
dM = decomposition(M, 'lu');
F = BuildThtRHS2d(msh.Mf, dt_f, Nt_f, theta, alpha*Yhat, Yhat(1, msh.in)', sparse(Nin,1));
X = dM\F; X = reshape(X, Nin, 2*Nt_f+2);
y_ref = X(:, 1:Nt_f+1); p = X(:, Nt_f+2:end);
u_ref= p/nu;