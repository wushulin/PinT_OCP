function value=TI_p(invAp,Ap,pn1,tau,bn)
global theta Nx
Ix=speye(Nx);
% this function is used to solve the semi-discrete 
% (adjoint) linear equation for one step: -p'+Ap=b(t)
% b(t) is a general source term
% theta-method: -p_{n+1}+p_n+tau*A*(theta*p_{n}+(1-theta)*p_{n+1})=tau*bn
value=invAp*((Ix-tau*(1-theta)*Ap)*pn1+tau*bn); 
end