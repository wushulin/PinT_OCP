function value=TI_y(invA,A,yn,tau,bn)
global theta Nx
Ix=speye(Nx);
% this function is used to solve the semi-discrete 
% (state) linear equation for one step: y'+Ay=b(t)
% b(t) is a general source term
 % theta-method: y_{n+1}-y_n+tau*A*(theta*y_{n+1}+(1-theta)*y_n)=tau*bn
value=invA*((Ix-tau*(1-theta)*A)*yn+tau*bn);
end