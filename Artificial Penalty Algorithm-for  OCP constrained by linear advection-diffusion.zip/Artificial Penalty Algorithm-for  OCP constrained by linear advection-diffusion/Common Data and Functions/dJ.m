function value=dJ(u,p)
global nu
value=nu*u-p;
end