function value=f(x,t)
value=0*x;
end
